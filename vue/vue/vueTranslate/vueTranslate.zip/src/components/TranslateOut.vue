<template>
  <div id="TranslateOut">
      <h2>{{translatedText}}</h2>
  </div>
</template>

<script>
  export default {
    name: 'TranslateOut',
    prop:[
     "translatedText"
    ],
    components:{

    }
  }
</script>

<style>
</style>
